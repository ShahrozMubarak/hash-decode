import { permanentRedirect } from "next/navigation";
export default function Alias(){permanentRedirect("/services");}
